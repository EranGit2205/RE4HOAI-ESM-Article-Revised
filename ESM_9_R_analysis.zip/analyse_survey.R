# RE4HOAI survey reanalysis using standard R statistical functions.
# Run from this folder:
#   Rscript analyse_survey.R survey_input.csv R_results
# Optional independent reference comparison:
#   Rscript analyse_survey.R survey_input.csv R_results ../survey_results
# No contributed R packages are required. Calculations use stats::kruskal.test
# and stats::p.adjust; the Kruskal-Wallis algorithm is not reimplemented here.

analyse_survey <- function(input = "survey_input.csv", out = "R_results",
                           reference_dir = NULL) {
  options(digits = 17, scipen = 999)
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  dat <- utils::read.csv(input, stringsAsFactors = FALSE, check.names = FALSE,
                         na.strings = c("", "NA"), fileEncoding = "UTF-8-BOM")
  item_names <- paste0("S", 1:11)
  required <- c("respondent_id", "age", "role", "risk", "familiarity", item_names)
  stopifnot(all(required %in% names(dat)), nrow(dat) == 58L,
            !anyDuplicated(dat$respondent_id), !anyNA(dat$age),
            all(dat$age >= 18), all(dat$age == floor(dat$age)))
  for (item in item_names) {
    dat[[item]] <- as.numeric(dat[[item]])
    stopifnot(all(is.na(dat[[item]]) | dat[[item]] %in% 1:5))
  }
  for (variable in c("role", "risk", "familiarity")) {
    dat[[variable]] <- trimws(dat[[variable]])
    stopifnot(!anyNA(dat[[variable]]), all(nzchar(dat[[variable]])))
  }
  dat$familiarity[dat$familiarity == "Basic familiarity"] <- "Basic"
  stopifnot(all(dat$risk %in% c("High", "Low", "Medium")),
            all(dat$familiarity %in% c("Basic", "Expert", "High", "Moderate")),
            all(dat$role %in% c("Academia", "Development team", "Management", "Operator")))
  dat$age_group <- as.character(cut(dat$age, breaks = c(17, 34, 44, 64, Inf),
    labels = c("Young Adult", "Early Middle Age", "Late Middle Age", "Senior"),
    right = TRUE))
  write_out <- function(object, name) {
    utils::write.csv(object, file.path(out, name), row.names = FALSE, na = "",
                     fileEncoding = "UTF-8")
  }
  write_out(dat, "processed_responses.csv")

  descriptive <- do.call(rbind, lapply(seq_along(item_names), function(i) {
    x <- dat[[item_names[i]]]
    x <- x[!is.na(x)]
    counts <- as.list(as.integer(table(factor(x, levels = 1:5))))
    names(counts) <- paste0("rating_", 1:5, "_n")
    data.frame(statement = i, n = length(x), missing = nrow(dat) - length(x),
      mean = mean(x), sd_sample = stats::sd(x),
      sd_population = sqrt(mean((x - mean(x))^2)),
      median = stats::median(x), minimum = min(x), maximum = max(x),
      counts, check.names = FALSE)
  }))
  write_out(descriptive, "descriptive_statistics.csv")
  write_out(descriptive[c("statement", "n", "mean", "sd_population", "minimum", "maximum")],
            "Table_6.csv")

  variables <- c(Risk = "risk", Familiarity = "familiarity", Role = "role", Age = "age_group")
  tests <- list()
  demographics <- list()
  group_summaries <- list()
  for (variable in names(variables)) {
    group <- dat[[variables[[variable]]]]
    counts <- table(group)
    # Eligibility is determined BEFORE itemwise deletion, consistently with
    # the stated exclusion rule. Academia has n=5 and is retained.
    eligible <- names(counts[counts >= 5L])
    demographics[[length(demographics) + 1L]] <- data.frame(
      variable = variable, group = names(counts), n = as.integer(counts),
      percent = 100 * as.integer(counts) / nrow(dat),
      eligible_for_tests = as.integer(counts) >= 5L)
    for (i in seq_along(item_names)) {
      keep <- group %in% eligible & !is.na(dat[[item_names[i]]])
      x <- dat[[item_names[i]]][keep]
      g <- factor(group[keep], levels = eligible)
      stopifnot(nlevels(g) >= 2L, all(table(g) > 0L))
      result <- stats::kruskal.test(x = x, g = g)
      h <- unname(result$statistic)
      k <- nlevels(g)
      n <- length(x)
      tests[[length(tests) + 1L]] <- data.frame(variable = variable, statement = i,
        n = n, k = k, H = h, df = unname(result$parameter),
        p_unadjusted = result$p.value, eta_squared_H = (h - k + 1) / (n - k),
        included_groups = paste(eligible, collapse = "; "),
        group_n = paste(as.integer(table(g)), collapse = "; "))
      for (label in eligible) {
        values <- x[g == label]
        group_summaries[[length(group_summaries) + 1L]] <- data.frame(
          variable = variable, statement = i, group = label, n = length(values),
          mean = mean(values), median = stats::median(values))
      }
    }
  }
  tests <- do.call(rbind, tests)
  stopifnot(nrow(tests) == 44L)
  # One family of all 44 comparisons; no post-hoc removal of tests.
  tests$p_holm_44 <- stats::p.adjust(tests$p_unadjusted, method = "holm", n = 44L)
  tests$p_bonferroni_44 <- stats::p.adjust(tests$p_unadjusted, method = "bonferroni", n = 44L)
  write_out(tests, "exploratory_tests.csv")
  write_out(do.call(rbind, demographics), "demographics.csv")
  write_out(do.call(rbind, group_summaries), "group_summaries.csv")

  table7 <- data.frame(Statement = 1:11)
  for (variable in names(variables)) {
    selected <- tests[tests$variable == variable, ]
    table7[[variable]] <- sprintf("%.4f (%.4f)", selected$p_unadjusted, selected$p_holm_44)
  }
  write_out(table7, "Table_7_unadjusted_and_Holm.csv")
  nominal <- tests[tests$p_unadjusted < 0.05, ]
  write_out(nominal, "nominal_comparisons.csv")
  summary <- c(paste("R:", R.version.string),
    paste("stats package:", as.character(utils::packageVersion("stats"))),
    paste("Respondents:", nrow(dat)), paste("Comparisons:", nrow(tests)),
    paste("Nominal p < .05:", nrow(nominal)),
    paste("Holm p < .05:", sum(tests$p_holm_44 < .05)),
    paste("Bonferroni p < .05:", sum(tests$p_bonferroni_44 < .05)),
    paste("Smallest unadjusted p:", format(min(tests$p_unadjusted), digits = 17)),
    paste("Smallest Holm p:", format(min(tests$p_holm_44), digits = 17)),
    "No post-hoc pairwise comparisons were performed.",
    "Age comparisons include only ages 35-44 (n=8) and 45-64 (n=43).",
    "Effect-size estimates are not truncated; small negative estimates can occur.",
    "Asymptotic inference with small groups and tied ordinal responses remains a limitation.")
  writeLines(summary, file.path(out, "analysis_summary.txt"))
  writeLines(utils::capture.output(utils::sessionInfo()), file.path(out, "sessionInfo.txt"))
  writeLines(utils::capture.output(utils::citation()), file.path(out, "R_citation.txt"))

  if (!is.null(reference_dir)) {
    reference <- utils::read.csv(file.path(reference_dir, "exploratory_tests.csv"),
      stringsAsFactors = FALSE, fileEncoding = "UTF-8-BOM")
    key <- function(d) paste(d$variable, d$statement, sep = ":")
    reference <- reference[match(key(tests), key(reference)), ]
    metrics <- c("n", "k", "H", "df", "p_unadjusted", "eta_squared_H", "p_holm_44", "p_bonferroni_44")
    differences <- vapply(metrics, function(metric) max(abs(tests[[metric]] - reference[[metric]])), numeric(1))
    write_out(data.frame(metric=names(differences), maximum_absolute_difference=as.numeric(differences)), "verification_differences.csv")
    stopifnot(!anyNA(differences), all(differences < 1e-10))
    ref_desc <- utils::read.csv(file.path(reference_dir, "descriptive_statistics.csv"),
      fileEncoding = "UTF-8-BOM")
    ref_desc <- ref_desc[match(descriptive$statement, ref_desc$statement), ]
    desc_metrics <- setdiff(names(descriptive), "statement")
    desc_differences <- vapply(desc_metrics, function(metric)
      max(abs(descriptive[[metric]] - ref_desc[[metric]])), numeric(1))
    stopifnot(!anyNA(desc_differences), all(desc_differences < 1e-10))
    writeLines(c("PASS: All 44 tests and all descriptive statistics agree with the earlier calculation within 1e-10.",
      "Maximum absolute differences for inferential outputs:",
      utils::capture.output(print(differences)), "Maximum absolute differences for descriptive outputs:",
      utils::capture.output(print(desc_differences))), file.path(out, "independent_verification.txt"))
  }
  cat(paste(summary, collapse = "\n"), "\n")
  invisible(list(descriptive = descriptive, tests = tests))
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  analyse_survey(if (length(args) >= 1L) args[1] else "survey_input.csv",
                if (length(args) >= 2L) args[2] else "R_results",
                if (length(args) >= 3L) args[3] else NULL)
}
