# RE4HOAI reproducible R survey analysis

## What was executed

All 44 group comparisons were run using R 4.6.0, standard stats package 4.6.0, via stats::kruskal.test(). Holm and Bonferroni adjustments were calculated using stats::p.adjust(). The R functions supply the test and adjustment implementations; these algorithms are not reimplemented in the analysis script.

Execution used webR 0.6.0, a local WebAssembly build of R hosted by Node.js. No respondent data were uploaded to a remote statistical service. The supplied .R script also runs under a regular desktop R installation without contributed packages. Full session details and the recommended R citation are included in R_results/.

## Run using R or RStudio

Unzip the package and set the working directory to this folder. In a terminal with R installed:

    Rscript analyse_survey.R survey_input.csv R_results

In the RStudio Console:

    source("analyse_survey.R")
    analyse_survey("survey_input.csv", "R_results")

This regenerates all output tables, summaries, processed data, and session information. No installation of readxl, tidyverse, or other contributed packages is required.

## Source data and traceability

survey_input.csv is a direct extraction of 58 records ,rows 2–59. It retains numeric age, original role/risk/familiarity labels, and the eleven item responses. Blank responses remain blank; R reads them as missing. Identifiers are sequential row identifiers. Personal timestamps and unrelated demographic fields are omitted because they do not enter this analysis.

## Explicit analysis decisions

1. Trim surrounding spaces in grouping labels and combine Basic familiarity with Basic.
2. Recode numeric age as 18–34, 35–44, 45–64, and 65+.
3. Determine eligible groups using at least five respondents before itemwise deletion. Academia (n=5) is retained; the two age groups with n=3 and n=4 are excluded.
4. Exclude missing responses separately for each item, without imputation. Statements 1, 5, and 10 each have one missing value.
5. Call stats::kruskal.test() on each item/grouping-variable combination. Report its tie-corrected H, df, and asymptotic chi-square p-value.
6. Calculate η²_H = (H − k + 1)/(n − k), with n equal to the non-missing sample in the included groups. Negative estimates are retained and documented.
7. Apply stats::p.adjust() to all 44 p-values as one family, using Holm and Bonferroni methods. No tests are removed after inspecting results.
8. Export both population and sample SD. Table_6.csv explicitly uses population SD, retaining the original descriptive convention.

## Outputs

- Table_6.csv: valid item n, means, population SD, and ranges.
- Table_7_unadjusted_and_Holm.csv: unadjusted p-values with Holm-adjusted values in parentheses.
- exploratory_tests.csv: full-precision H, df, n, k, effect-size estimates, group n, and all p-values.
- descriptive_statistics.csv: complete descriptive statistics and response frequencies.
- demographics.csv: corrected category counts and test eligibility.
- group_summaries.csv: itemwise n, mean, and median in eligible groups.
- processed_responses.csv: auditable data after R recoding.
- nominal_comparisons.csv: the five unadjusted comparisons below .05.
- analysis_summary.txt, sessionInfo.txt, R_citation.txt: conclusions, environment, and citation.
- independent_verification.txt: comparison of the actual R run with the earlier independently calculated full-precision results. This verification file is historical evidence of the checked run, not a prerequisite for regenerating the main results.

## Findings and limits

R reproduces the corrected results within numerical precision (maximum absolute discrepancy below 1e-10). Statement 10 by risk gives H=13.4402235863652, unadjusted p=.00120640333875038, η²_H=.211855992340096, and Holm-adjusted p=.0530817469050169. Five comparisons are nominally significant; none is significant after Holm or Bonferroni correction at .05.

Only ages 35–44 and 45–64 are eligible for the age comparisons. Those results do not characterize the full age range. Tied ordinal responses and small groups limit asymptotic inference. No pairwise post-hoc tests were performed. This reanalysis does not identify the historical cause of the original calculator discrepancies, establish equivalence between non-significant groups, or demonstrate framework effectiveness.
