# RE4HOAI – survey reproducibility analysis (Online Resource 9)
# Base R only; no third-party packages are needed.
# Reproduces the analytical tables in ESM_8_Revised.xlsx.
# Post-hoc p-values may differ from SPSS in the final displayed digit
# because SPSS reports rounded rank statistics and significances.
# Usage: Rscript analyse_survey_ESM8.R [path/to/survey_input.csv] [output_dir]
# By default, the input CSV is expected beside this script and outputs are
# written to a folder named survey_results beside the input file.
# This script independently reproduces the analysis; it is NOT an SPSS log.

args <- commandArgs(trailingOnly = TRUE)
full_args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep('^--file=', full_args, value = TRUE)
script_dir <- if (length(file_arg)) dirname(normalizePath(sub('^--file=', '', file_arg[1]))) else getwd()
input_file <- if (length(args) >= 1) args[1] else file.path(script_dir, 'survey_input.csv')
output_dir <- if (length(args) >= 2) args[2] else file.path(dirname(normalizePath(input_file, mustWork = TRUE)), 'survey_results')
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

survey <- read.csv(input_file, stringsAsFactors = FALSE, na.strings = c('', 'NA'), check.names = FALSE)
items <- paste0('S', 1:11)
variables <- c('age', 'role', 'risk', 'familiarity', items)
missing_cols <- setdiff(variables, names(survey))
if (length(missing_cols)) stop('Missing columns: ', paste(missing_cols, collapse = ', '))
for (nm in c('age', items)) {
  if (!is.numeric(survey[[nm]])) stop('Expected numeric column: ', nm)
}
for (nm in items) {
  observed <- survey[[nm]][!is.na(survey[[nm]])]
  if (any(!observed %in% 1:5)) stop('Item ', nm, ' contains values outside Likert 1–5')
}
# Trim surrounding whitespace (including tabs, newlines and non-breaking spaces)
# before validating familiarity labels; keep the existing factor order and analysis.
survey$familiarity <- trimws(survey$familiarity, whitespace = "[\\h\\v]")
# Define factor order explicitly for consistent labels and reproducible outputs.
levels_by_group <- list(
  risk = c('High', 'Medium', 'Low'),
  familiarity = c('Basic', 'Moderate', 'High', 'Expert'),
  role = c('Academia', 'Operator', 'Management', 'Development team')
)
for (g in names(levels_by_group)) {
  unknown <- setdiff(unique(na.omit(survey[[g]])), levels_by_group[[g]])
  if (length(unknown)) stop('Unknown values in ', g, ': ', paste(unknown, collapse = ', '))
  survey[[g]] <- factor(survey[[g]], levels = levels_by_group[[g]])
}

# 1. Descriptive summaries. SD is calculated as population SD to match the
# manuscript's Table 6; base R's sd() otherwise returns sample SD.
descriptive <- do.call(rbind, lapply(items, function(item) {
  x <- survey[[item]]
  x <- x[!is.na(x)]
  data.frame(statement = item, n = length(x), mean = mean(x),
             sd_population = sqrt(mean((x - mean(x))^2)),
             sd_sample = sd(x), min = min(x), max = max(x))
}))
write.csv(descriptive, file.path(output_dir, 'descriptive_statistics.csv'), row.names = FALSE, na = '')

# 2. The 44 primary tests: 33 Kruskal-Wallis tests and 11 Spearman tests.
# Spearman p-values from cor.test() use R's built-in tie-aware approximation
# when ties exist (as here); this may differ slightly between software.
primary <- list()
for (item in items) {
  x <- survey[[item]]
  for (g in c('risk', 'familiarity', 'role')) {
    use <- !is.na(x) & !is.na(survey[[g]])
    y <- x[use]
    f <- droplevels(survey[[g]][use])
    if (nlevels(f) < 2) stop('Insufficient groups: ', item, ' / ', g)
    kt <- kruskal.test(y ~ f)
    N <- length(y); k <- nlevels(f); H <- unname(kt$statistic)
    primary[[length(primary) + 1L]] <- data.frame(statement = item,
      variable = g, method = 'Kruskal-Wallis', n = N, statistic = H,
      df = unname(kt$parameter), p_unadjusted = kt$p.value,
      eta2_H = if (N > k) (H - k + 1)/(N - k) else NA_real_)
  }
  keep <- complete.cases(survey[, c('age', item)])
  st <- suppressWarnings(cor.test(survey$age[keep], x[keep],
                                  method = 'spearman', alternative = 'two.sided', exact = FALSE))
  primary[[length(primary) + 1L]] <- data.frame(statement = item,
    variable = 'age', method = 'Spearman', n = sum(keep),
    statistic = unname(st$estimate), df = NA_real_,
    p_unadjusted = st$p.value, eta2_H = NA_real_)
}
primary <- do.call(rbind, primary)
stopifnot(nrow(primary) == 44L)
primary$p_holm_44 <- p.adjust(primary$p_unadjusted, method = 'holm')
write.csv(primary, file.path(output_dir, 'primary_tests_44.csv'), row.names = FALSE, na = '')

# 3. SPSS Independent-Samples Kruskal-Wallis pairwise comparisons.
# Differences in mean ranks are standardized using tie-corrected pooled-rank
# variance. Asymptotic two-sided normal p-values are Bonferroni-adjusted
# WITHIN each post-hoc family, matching SPSS Pairwise Comparisons.
# These are exploratory when Holm across all 44 primary tests is not significant.
spss_pairwise <- function(response, group) {
  ok <- !is.na(response) & !is.na(group)
  y <- response[ok]; f <- droplevels(group[ok]); N <- length(y)
  ranks <- rank(y, ties.method = 'average')
  tie_sizes <- as.numeric(table(y))
  # Dunn rank variance with correction for ties on the ordinal scale.
  rank_var <- N * (N + 1) / 12 - sum(tie_sizes^3 - tie_sizes) / (12 * (N - 1))
  labels <- levels(f)
  comparisons <- combn(labels, 2, simplify = FALSE)
  res <- do.call(rbind, lapply(comparisons, function(pair) {
    ga <- f == pair[1]; gb <- f == pair[2]
    mra <- mean(ranks[ga]); mrb <- mean(ranks[gb])
    se <- sqrt(rank_var * (1 / sum(ga) + 1 / sum(gb)))
    z <- (mra - mrb) / se
    data.frame(group_a = pair[1], group_b = pair[2],
               mean_rank_difference = mra - mrb, standard_error = se,
               n_a = sum(ga), n_b = sum(gb),
               mean_rank_a = mra, mean_rank_b = mrb,
               z = z, p_unadjusted = 2 * pnorm(-abs(z)))
  }))
  res$p_bonferroni_within_family <- p.adjust(res$p_unadjusted, method = 'bonferroni')
  res
}
posthoc_list <- list()
nominal_kw <- subset(primary, method == 'Kruskal-Wallis' & p_unadjusted < .05)
for (i in seq_len(nrow(nominal_kw))) {
  q <- nominal_kw[i, ]
  result <- spss_pairwise(survey[[q$statement]], survey[[q$variable]])
  result <- cbind(data.frame(statement = q$statement, variable = q$variable,
                             omnibus_p = q$p_unadjusted,
                             omnibus_p_holm_44 = q$p_holm_44), result)
  posthoc_list[[length(posthoc_list) + 1L]] <- result
}
posthoc <- if (length(posthoc_list)) do.call(rbind, posthoc_list) else
  data.frame(statement = character(), variable = character(),
             omnibus_p = numeric(), omnibus_p_holm_44 = numeric(),
             group_a = character(), group_b = character(),
             mean_rank_difference = numeric(), standard_error = numeric(),
             n_a = integer(), n_b = integer(), mean_rank_a = numeric(),
             mean_rank_b = numeric(), z = numeric(),
             p_unadjusted = numeric(), p_bonferroni_within_family = numeric())
write.csv(posthoc, file.path(output_dir, 'spss_pairwise_bonferroni_all.csv'), row.names = FALSE)
write.csv(subset(posthoc, p_bonferroni_within_family < .05),
          file.path(output_dir, 'spss_pairwise_bonferroni_nominal.csv'), row.names = FALSE)

# 4. Report checks and basic provenance.
checks <- c(paste('R version:', R.version.string),
            paste('Input:', normalizePath(input_file)),
            paste('Participants:', nrow(survey)),
            paste('Primary tests:', nrow(primary)),
            paste('Nominal KW tests (p < .05):', nrow(nominal_kw)),
            paste('SPSS-style pairwise contrasts:', nrow(posthoc)),
            paste('Primary tests surviving global Holm:', sum(primary$p_holm_44 < .05)),
            paste('Missing per item:', paste(sprintf('%s=%d', items,
                         colSums(is.na(survey[items]))), collapse = ', ')),
            'Main interpretation rule: primary significance requires p_holm_44 < .05.',
            'Bonferroni post-hoc results after nominal omnibus p < .05 are exploratory.')
writeLines(checks, file.path(output_dir, 'analysis_checks.txt'))
cat(paste(checks, collapse = '\n'), '\n')
